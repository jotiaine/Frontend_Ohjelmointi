"use strict";

let cards = [
  "2_of_clubs.png",
  "3_of_diamonds.png",
  "4_of_hearts.png",
  "5_of_spades.png",
  "6_of_clubs.png",
  "7_of_diamonds.png",
  "8_of_hearts.png",
  "9_of_spades.png",
  "10_of_clubs.png",
  "ace_of_spades.png",
  "black_joker.png",
  "jack_of_diamonds.png",
  "king_of_hearts.png",
  "queen_of_hearts.png",
  "red_joker.png",
];

let randomCardsArr = [];

let randomNumber;
let randomCard;
let clicks = 0;
let tries = 0;
let timer;
let seconds = 0;

// jQuery
$(document).ready(function () {
  let bodyEl = $("body");
  const gameAreaContainerEl = document.querySelector(".gamearea-container");

  function getRandomCardArr() {
    for (let i = 0; i < cards.length; i++) {
      randomNumber = Math.floor(Math.random() * cards.length);

      randomCardsArr.push(cards[randomNumber]);
      cards.splice(randomNumber, 1);
    }

    return randomCardsArr, cards;
  }

  bodyEl.animate(
    {
      opacity: "1",
      left: "0",
    },
    "slow"
  );

  // Start game
  $(".btn-start-game").click(function () {
    gameAreaContainerEl.classList.remove("hide");

    setInterval(function () {
      // Showcasing end modal
      if (seconds > 30) {
        location.reload();
      }

      seconds++;
      $(".timer").html(seconds);
    }, 1000);

    // FadeOut starting modal
    $(".btn-modal").fadeOut("slow", function () {
      $(".gamearea-container").animate(
        {
          opacity: "1",
        },
        "slow"
      );
    });

    $(".card").click(function () {
      clicks++;
      if (clicks % 2 === 0) {
        tries++;
        $(".tries").html(tries);
      }

      // if () {
      //   $(this).attr("src") === ;

      // }
    });

    getRandomCardArr();
    $(".card1").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[0]}`);
    });
    $(".card2").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[1]}`);
    });
    $(".card3").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[2]}`);
    });
    $(".card4").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[3]}`);
    });
    $(".card5").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[4]}`);
    });
    $(".card6").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[5]}`);
    });
    $(".card7").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[6]}`);
    });
    $(".card8").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[7]}`);
    });
    $(".card9").click(function () {
      $(this).attr("src", `img/cards/${cards[0]}`);
    });
    $(".card10").click(function () {
      $(this).attr("src", `img/cards/${cards[1]}`);
    });
    $(".card11").click(function () {
      $(this).attr("src", `img/cards/${cards[2]}`);
    });
    $(".card12").click(function () {
      $(this).attr("src", `img/cards/${cards[3]}`);
    });
    $(".card13").click(function () {
      $(this).attr("src", `img/cards/${cards[4]}`);
    });
    $(".card14").click(function () {
      $(this).attr("src", `img/cards/${cards[5]}`);
    });
    $(".card15").click(function () {
      $(this).attr("src", `img/cards/${cards[6]}`);
    });

    // Second randomArray
    cards = [
      "6_of_clubs.png",
      "3_of_diamonds.png",
      "4_of_hearts.png",
      "2_of_clubs.png",
      "5_of_spades.png",
      "9_of_spades.png",
      "king_of_hearts.png",
      "10_of_clubs.png",
      "7_of_diamonds.png",
      "ace_of_spades.png",
      "red_joker.png",
      "black_joker.png",
      "8_of_hearts.png",
      "queen_of_hearts.png",
      "jack_of_diamonds.png",
    ];

    randomCardsArr = [];

    getRandomCardArr();

    $(".card16").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[5]}`);
    });
    $(".card17").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[7]}`);
    });
    $(".card18").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[2]}`);
    });
    $(".card19").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[6]}`);
    });
    $(".card20").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[1]}`);
    });
    $(".card21").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[0]}`);
    });
    $(".card22").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[3]}`);
    });
    $(".card23").click(function () {
      $(this).attr("src", `img/cards/${randomCardsArr[4]}`);
    });
    $(".card24").click(function () {
      $(this).attr("src", `img/cards/${cards[0]}`);
    });
    $(".card25").click(function () {
      $(this).attr("src", `img/cards/${cards[1]}`);
    });
    $(".card26").click(function () {
      $(this).attr("src", `img/cards/${cards[2]}`);
    });
    $(".card27").click(function () {
      $(this).attr("src", `img/cards/${cards[3]}`);
    });
    $(".card28").click(function () {
      $(this).attr("src", `img/cards/${cards[4]}`);
    });
    $(".card29").click(function () {
      $(this).attr("src", `img/cards/${cards[5]}`);
    });
    $(".card30").click(function () {
      $(this).attr("src", `img/cards/${cards[6]}`);
    });
  });
});

// Keskeneräinen: Tarkista kortit ovatko samat ja jätä silloin näkyviin ne
